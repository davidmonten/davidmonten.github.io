// LED 
#include <avr/io.h>
#include <util/delay.h>


int main()
{
	//SETUP
	//LED is PB2


	DDRB = _BV(PB2); //Enable output on the LED pin
	PORTB = _BV(PB2); //Turns LED on

}