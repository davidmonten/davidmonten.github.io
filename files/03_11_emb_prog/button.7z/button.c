
 hello.arduino.328P.blink.c

 test blinking LED

 Neil Gershenfeld
 102113


#include avrio.h
#include utildelay.h
#define input(directions, pin) (directions &= (~pin))
#define output(directions,pin) (directions = pin)  set port direction for output
#define set(port,pin) (port = pin)  set port pin
#define clear(port,pin) (port &= (~pin))  clear port pin
#define pin_test(pins,pin) (pins & pin)  test for port pin
#define bit_test(byte,bit) (byte & (1  bit))  test for bit set
#define led_delay() _delay_ms(100)  LED delay

#define led_port PORTB		sistema per scrivere sul pin
#define led_direction DDRB	sistema per inpostare se � input o output
#define led_pin (1  PB2)	bitmask della portB, pin2
#define but_direc DDRA		sistema per impostare la portA � input o output
#define but_port PORTA		sistema per scrivere sui pin della porta A, od abilitare il pull up
#define but_pin (1 PA7)	bitmask della portA, pin7
#define but_read PINA		sistema pe' legge'

int main(void) {

    main

    set clock divider to 1

   CLKPR = (1  CLKPCE);
   CLKPR = (0  CLKPS3)  (0  CLKPS2)  (0  CLKPS1)  (0  CLKPS0);

    initialize LED pin

   clear(led_port, led_pin); 		digitalWrite(pin,LOW);
   output(led_direction, led_pin); 	pinMode(pin, OUTPUT);



   INIZIALIZA BUTTON
   set(but_port,but_pin);		attiva il pull-up
   input(but_direc, but_pin);		inizializza il pulsante come input

   while(1){				 main loop
   	if (pin_test(but_read,but_pin)==0) {
   		set(led_port, led_pin); 	TURN ON PIN
   		led_delay();
   		clear(led_port, led_pin); TURN OFF PIN
   		led_delay();
   	}
   }
}
