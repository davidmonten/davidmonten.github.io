#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#define output(directions,pin) (directions |= pin) // set port direction for output
#define input(directions,pin) (directions &= (~pin)) // set port direction for input
#define set(port,pin) (port |= pin) // set port pin
#define clear(port,pin) (port &= (~pin)) // clear port pin
#define pin_test(pins,pin) (pins & pin) // test for port pin
#define bit_test(byte,bit) (byte & (1 << bit)) // test for bit set

#define led_delay() _delay_ms(1) // LED delay

#define PORTBUTTON PORTA
#define PINBUTTON PA7

unsigned short int icounter = 0; // the index of the counter currently working

const unsigned short int duty = 8;
const unsigned short int leisure = 8;
const unsigned short int needs = 8;

const unsigned short int dutyRst = 8;
const unsigned short int leisureRst = 8;
const unsigned short int needsRst = 8;

volatile unsigned short int ledOn = 0;

volatile unsigned long timeResid[3] = {57600, 57600, 57600};   //set of residual values

unsigned short int buttonStatusOld = 0;

/********* MATRIX PART  ***********/


//#define led_port PORTA

//#define led_direction DDRA

//David's pinout
#define A 0 // led pin A
#define B 1 // led pin B
#define C 2 // led pin C
#define D 3 // led pin D
#define E 4 // led pin E
#define BUTTON (1 << PB7) // button pin

//ARRAY of ordered combinations of pins (Vcc-Gnd)to light on a single led
//pins named from 0 to 4 as reported in David's pinout macros
int led[15][2]={
        {0,1},
        {1,0},
        {0,2},
        {2,0},
        {0,3},
        {3,0},
        {0,4},
        {4,0},
        {1,2},
        {2,1},
        {1,3},
        {3,1},
        {1,4},
        {4,1},
        {2,3}
};


//function to retrieve the PIN MASK using the pin name
//pins named from 0 to 4 as reported in David's pinout macros
unsigned short int ledPin(unsigned short int pinName){
 if (pinName == A){
   return (1<< PA2);
 }
if (pinName == B){
   return (1<< PA3);
 }
if (pinName == C){
   return (1<< PB0);
 }
if (pinName == D){
   return (1<< PB1);
 }
if (pinName == E){
   return (1<< PB2);
 }
 return 0;
}


//function to retrieve the PORTn using the pin name
//pins named from 0 to 4 as reported in David's pinout macros
volatile uint8_t* ledPort(unsigned short int pinName){
 if (pinName == A || pinName == B) {
     return &PORTA;
 } else {
     return &PORTB;
 }
}


//function to retrieve the INDEX of the value DDR using the pin name
//pins named from 0 to 4 as reported in David's pinout macros
volatile uint8_t* ledDir(unsigned short int pinName){
 if (pinName == A || pinName == B) {
     return &DDRA;
 } else {
     return &DDRB;
 }
}

/* funzioni non utilizzate
//this function manage how to turn on and off every single led
//void flash(unsigned short int f, unsigned short int t, unsigned short int delay) {
    
   //
   // source from, sink to, flash
   //
   unsigned short int from = ledPin(f);
   unsigned short int to = ledPin(t);
   
   *ledPort(from) |= from;      //set the pin  as HIGH
   *ledPort(to) &= (~to);       //set the pin  as LOW

   *ledDir(from) |= from;		//set the port direction as OUT
   *ledDir(to) |= to;			//set the port direction as OUT
   
   
   //this turn off the led for a "led_delay" amount of time
   
   static unsigned short int i;
   
   for (i = 0; i < delay; ++i)
       led_delay();
   
   
   
   *ledDir(from)  &= (~from) ;	// set as INPUT the pin 'form'
   *ledDir(to)  &= (~to) ;		// set as INPUT the pin 'to'
}


//this is the function that manage the display
//it is like a cycle
//but very fast and just for the correct leds
void matrix_display(unsigned short int number, unsigned short int delay) {
   //
   // cycle through LEDs
   //
   unsigned short int i;

   for (i = 0; i < number; ++i) {
      flash(B,A,delay);
      flash(C,A,delay);
      flash(D,A,delay);
      flash(E,A,delay);
      flash(A,B,delay);
      flash(C,B,delay);
      flash(D,B,delay);
      flash(E,B,delay);
      flash(A,C,delay);
      flash(B,C,delay);
      flash(D,C,delay);
      flash(E,C,delay);
      flash(A,D,delay);
      flash(B,D,delay);
      flash(C,D,delay);
      flash(E,D,delay);
      flash(A,E,delay);
      flash(B,E,delay);
      flash(C,E,delay);
      flash(D,E,delay);
      }
}
*/

// set all the pin as INPUT
void clearAll(){
	
	*ledDir(ledPin(A))  &= (~ledPin(A)) ;	// set as INPUT the pin 'A'
	*ledDir(ledPin(B))  &= (~ledPin(B)) ;	// set as INPUT the pin 'B'
	*ledDir(ledPin(C))  &= (~ledPin(C)) ;	// set as INPUT the pin 'C'
	*ledDir(ledPin(D))  &= (~ledPin(D)) ;	// set as INPUT the pin 'D'
	*ledDir(ledPin(E))  &= (~ledPin(E)) ;	// set as INPUT the pin 'E'
	
}


//function to turn on a led using it's index
void setTheLed(unsigned short int ledNumber) {
	
	clearAll();
	
	unsigned short int from = ledPin(led[ledNumber][0]);
	unsigned short int to = ledPin(led[ledNumber][1]);
	
	*ledPort(from) |= from;      //set the pin  as HIGH
	*ledPort(to) &= (~to);       //set the pin  as LOW

	*ledDir(from) |= from;		//set the port direction as OUT
	*ledDir(to) |= to;			//set the port direction as OUT
  
}

//function to turn on a led using it's index
void clearTheLed(unsigned short int ledNumber) {
	
	unsigned short int from = ledPin(led[ledNumber][0]);
	unsigned short int to = ledPin(led[ledNumber][1]);

	*ledDir(from) &= (~from);		//set the port direction as IN
	*ledDir(to) &= (~to);			//set the port direction as IN
  
}

/********** END MATRIX PART ***********/


// Timer #0 - 
// Used for LED matrix refresh
ISR(TIM0_COMPA_vect){
        unsigned short int perfive;   //this is not a percentual, because goes from 0 (minimum) to 5 (maximum)
    // update matrix

    // Which row I have to manage now?
    if (ledOn < 5) {    			// duty
                
                perfive = ( timeResid[0] * 5 ) / ( 3600 * duty * 2);
                
                // If ledOn (a counter variable) is lower than timeResid's percentual,
                // the led number "ledOn" must be turned on
				
                if ( ledOn < perfive ) {
					
                         setTheLed(ledOn);
						 
                }
        
    }
    else if (ledOn < 10){    		// leisure
	
                perfive = ( timeResid[1] * 5 ) / ( 3600 * leisure * 2);
				
                // If ledOn (a counter variable) is lower than timeResid's percentual,
                // the led number "ledOn" must be turned on
                if ( ( ledOn - 5 ) < perfive ) {
					
                         setTheLed(ledOn);
						 
                }
    }
    else if (ledOn < 15){    		// or needs
	
                perfive = ( timeResid[2] * 5 ) / ( 3600 * needs * 2);
				
                // If ledOn (a counter variable) is lower than timeResid's percentual,
                // the led number "ledOn" must be turned on
                if ( ( ledOn - 10 ) < perfive ) {
					
                         setTheLed(ledOn);
						 
                }
    }


    if (ledOn < 14)
        ledOn++;
    else
        ledOn = 0;
}



// Timer #1 - period of (about) 1s [ => frequency 1 Hz ]
// Used for timeResid refresh
ISR(TIM1_COMPA_vect) {
    if ( timeResid[icounter] != 0 ) {        // if the couter still has credits
        timeResid[icounter] -= 2;            // so subtract two
    }
    else {
                                            // but if the time of the active counter has ran out
                                            // subtract 1 credit to the other counters
                                            // and if also an unactive counter has ran out of time
                                            // subtract 2 credits to the last standing counter
        
        if (icounter == 0 ) {                
            
            if (timeResid[1] > 0 && timeResid[2] > 0) {
                    
                    timeResid[1] --;
                    timeResid[2] --;
              
            }  else if (timeResid[2] > 0) {
                    
                    timeResid[1] -= 2;                    
              
            } else if ( timeResid[1] > 0) {
                    
                    timeResid[2] -= 2;                    
              
            } 
        }
            
        if (icounter == 1 ) {
            if (timeResid[0] > 0 && timeResid[2] > 0) {
                    
                    timeResid[0] --;
                    timeResid[2] --;
              
            }  else if (timeResid[0] > 0) {
                    
                    timeResid[0] -= 2;                    
              
            } else if ( timeResid[1] > 0) {
                    
                    timeResid[2] -= 2;                    
              
            } 

        }
            
        if (icounter == 2 ) {
            if (timeResid[0] > 0 && timeResid[2] > 0) {
                    
                    timeResid[0] --;
                    timeResid[2] --;
              
            }  else if (timeResid[0] > 0) {
                    
                    timeResid[0] -= 2;                    
              
            } else if ( timeResid[1] > 0) {
                    
                    timeResid[2] -= 2;                    
              
            } 
        }
    }

    if (timeResid[0] == 0 && timeResid[1] == 0 && timeResid[2] == 0) {
             //~ duty = dutyRst;
             //~ leisure = leisureRst;
             //~ needs = needsRst;
             timeResid[0] = timeResid[1] = timeResid[2] = 57600;
    }
}
		
        
        /* switches
        switch(icounter) {
			
            case 0:
				if ( timeResid[1] != 0 )
				{
					timeResid[0] -= 2;
				}
				else
					timeResid[1] --;
					timeResid[2] --;

				break;
				
            case 1:
				if ( timeResid[1] != 0 )
				{
					timeResid[1] -= 2;
				}
				else
					timeResid[0] --;
					timeResid[2] --;
            break;
            
            case 2:
				if ( timeResid[2] != 0 )
				{
					timeResid[2] -= 2;
				}
				else
					timeResid[0] --;
					timeResid[1] --;
            break;
        }
    }

}
*/


int main() {
   
   // clock timer
    TCCR1B |= ( 1<<WGM12);                  //CTC mode
   // TCCR1B |= ( (1<<CS10) | (1 << CS12) );  //1024 prescaler
	  TCCR1B |= ( (1<<CS10) );
	
    TIMSK1 |= (1<< OCIE1A);




    // display frequency timer
    TCCR0B |= ( 1<<WGM02);          //overflow mode
    TCCR0B |= ( (1<<CS00) );        // No prescaler

    TIMSK0 |= (1<< OCIE0A);

    sei();

    OCR1A = 976;                    //clock cycles per second (1MHz / 1024 prescaler)

    OCR0A = 100;                    // Update frequency of display: 1Mhz / 100 = 10kHz
    

    while(1) {
        if (buttonStatusOld == 0 && !(PORTBUTTON & (1 << PA7))) {   // Pull UP
			
            buttonStatusOld = 1;
            
            if (icounter < 2) {
                icounter++;
            } else {
                icounter = 0;
            }
        }
		else {
			if(buttonStatusOld == 1 && (PORTBUTTON & ~(1 << PA7))){
				icounter = 2;
			}
		}
  }    
}


