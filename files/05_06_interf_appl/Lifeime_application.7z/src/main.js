$(document).ready(function(){

var received = $('#received');


var socket = new WebSocket("ws://localhost:8080/ws");
 
socket.onopen = function(){  
  console.log("connected"); 
}; 

socket.onmessage = function (message) {
  console.log("receiving: " + message.data);
  received.append(message.data);
  received.append($('<br/>'));
};

socket.onclose = function(){
  console.log("disconnected"); 
};

var sendMessage = function(message) {
  console.log("sending:" + message.data);
  socket.send(message.data);
};

var duty_val = 8;
var leisure_val = 8;
var needs_val = 8;




//function balance(){
//duty_val + leisure_val == 24 - needs_val;


$("#duty_val").change(function(){
	var val = $('#duty_val').val();
	var diff = val - duty_val;
	duty_val = val;
	
	leisure_val = leisure_val - (diff/2);
	$("#leisure_val").val(leisure_val);
	
	needs_val = needs_val - (diff/2);
	$("#needs_val").val(needs_val);
	
});

$("#leisure_val").change(function(){
	var val = $('#leisure_val').val();
	var diff = val - leisure_val;
	leisure_val = val;
	
	duty_val = duty_val - (diff/2);
	$("#duty_val").val(duty_val);
	
	needs_val = needs_val - (diff/2);
	$("#needs_val").val(needs_val);
    
});

$("#needs_val").change(function(){
	var val = $('#needs_val').val();
	var diff = val - needs_val;
	needs_val = val;
    
	duty_val = duty_val - (diff/2);
	$("#duty_val").val(duty_val);
	
	leisure_val = leisure_val - (diff/2);
	$("#leisure_val").val(leisure_val);
});


// GUI Stuff


// send a command to the serial port
$("#cmd_send").click(function(ev){
  ev.preventDefault();
  var cmd = $('#cmd_value').val();
  sendMessage({ 'data' : cmd});
  $('#cmd_value').val("");
});

$('#clear').click(function(){
  received.empty();
});


});
