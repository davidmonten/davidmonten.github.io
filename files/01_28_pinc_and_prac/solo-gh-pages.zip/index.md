---
layout: default
---
_The Fab Academy is a Digital Fabrication Program
directed by Neil Gershenfeld of MIT's Center for Bits and Atoms
and based on MIT's rapid prototyping course
MAS 863:
**How to Make (Almost) Anything**_  

<!---
PUT HERE AN UPDATE WIDGET
TO MONITORING NEWS ON EVERY PAGE OF THE SITE
-->

##Project Description  
  
###Subject  
An wargame set in outerspace with an interactive and modular scenario.  

![concept](/img/home/concept.jpg)  
Every modules will be sensible to different kind of ships and will provide usefull informations for an enhanched gameplay.
The game will allow to be played as a phisical game, being phisically immersed into the scenario to play the game and moving every piece by hand while the great part of the digital aspects will be "almost-unperceiveble".  

![section](/img/home/section.jpg)  

  
###Goals  
* Build the planet modules in an easy, cheap and modular way.  
* Build different kind of ships, buildings and defences.  
* Allow the planet to recognize every different ship.  
* Allow the planets to regognize them as members of the same party.  
* Allow the planets to communicate their status easly and directly to the player trough lighi and sound.  
* Allow the planets to measure the distance between them to enable/disable some actions.  
* Manage some functions via web application.  
* Build a large frame (named "known space") to set the game's space hanging up the planets.  
* Make a web site to collect all the documentation and show the work in progress
  
###Design considerations  
* A game is essentially a set of rules that define one or more purposes, some ways to reach it and forbidden behaviours. All that is not inherent with the Fab Academy's purposes and will not be developed. Th project will be about a framework of devices to use to write a set of rules.  

* That kind of game need a great amount of time to set up a match. That imply a great motivation and a long duration of the match to justify the setting time so virtually this game could be infinite adding new space game, new planets, new fleet and new parties.  

* The planets will not be spherical but polihedrical to define a number of slot that can host pieces (like ships and buildings). The join between planet and pieces will be made by magnets, so it provides both an easy snap of the pieces and elettrical contact at the same time. The facec can be made in different material to customize the planet and even if the material is not transparent light feedback will be visible trough not merged edges.  

* The frame of the known space will be modular too to expand the space of the game.  
  